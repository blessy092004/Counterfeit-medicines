import React, { useState, useEffect } from 'react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2, AlertCircle, Package, Users, Activity } from 'lucide-react';

import Navbar from './components/Navbar';
import DrugBatchForm from './components/DrugBatchForm';
import DrugBatchCard from './components/DrugBatchCard';
import TransferModal from './components/TransferModal';
import HistoryModal from './components/HistoryModal';

import { 
  initWeb3, 
  getContract, 
  getCurrentAccount, 
  getAccounts,
  formatDate 
} from './utils/web3';

import './App.css';

function App() {
  const [web3, setWeb3] = useState(null);
  const [contract, setContract] = useState(null);
  const [currentAccount, setCurrentAccount] = useState('');
  const [userRole, setUserRole] = useState(null);
  const [drugBatches, setDrugBatches] = useState([]);
  const [participants, setParticipants] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  
  // Modal states
  const [transferModal, setTransferModal] = useState({ isOpen: false, batchId: null });
  const [historyModal, setHistoryModal] = useState({ isOpen: false, batch: null, history: null });
  
  // Form loading states
  const [createLoading, setCreateLoading] = useState(false);
  const [transferLoading, setTransferLoading] = useState(false);

  useEffect(() => {
    initializeApp();
  }, []);

  const initializeApp = async () => {
    try {
      setLoading(true);
      const web3Instance = await initWeb3();
      const contractInstance = await getContract();
      const account = await getCurrentAccount();
      
      setWeb3(web3Instance);
      setContract(contractInstance);
      setCurrentAccount(account);
      
      if (account) {
        await loadUserData(contractInstance, account);
      }
    } catch (error) {
      console.error('Error initializing app:', error);
      setError('Failed to connect to blockchain. Please make sure MetaMask is installed and connected.');
    } finally {
      setLoading(false);
    }
  };

  const loadUserData = async (contractInstance, account) => {
    try {
      // Get user role
      const participant = await contractInstance.methods.getParticipant(account).call();
      setUserRole(participant.role ? parseInt(participant.role) : null);
      
      // Load drug batches
      await loadDrugBatches(contractInstance);
      
      // Load participants for transfer modal
      await loadParticipants(contractInstance);
    } catch (error) {
      console.error('Error loading user data:', error);
    }
  };

  const loadDrugBatches = async (contractInstance) => {
    try {
      const totalBatches = await contractInstance.methods.getTotalBatches().call();
      const batches = [];
      
      for (let i = 1; i <= totalBatches; i++) {
        try {
          const batch = await contractInstance.methods.getDrugBatch(i).call();
          const isExpired = await contractInstance.methods.isDrugExpired(i).call();
          
          batches.push({
            batchId: batch.batchId,
            drugName: batch.drugName,
            manufacturer: batch.manufacturer,
            manufacturingDate: batch.manufacturingDate,
            expiryDate: batch.expiryDate,
            quantity: batch.quantity,
            status: parseInt(batch.status),
            currentOwner: batch.currentOwner,
            isExpired
          });
        } catch (error) {
          console.error(`Error loading batch ${i}:`, error);
        }
      }
      
      setDrugBatches(batches);
    } catch (error) {
      console.error('Error loading drug batches:', error);
    }
  };

  const loadParticipants = async (contractInstance) => {
    try {
      const accounts = await getAccounts();
      const participantList = [];
      
      for (const account of accounts) {
        try {
          const participant = await contractInstance.methods.getParticipant(account).call();
          if (participant.isActive && account !== currentAccount) {
            participantList.push({
              address: account,
              name: participant.name,
              role: parseInt(participant.role),
              location: participant.location
            });
          }
        } catch (error) {
          // Participant not registered, skip
        }
      }
      
      setParticipants(participantList);
    } catch (error) {
      console.error('Error loading participants:', error);
    }
  };

  const handleConnect = async () => {
    try {
      await initializeApp();
    } catch (error) {
      setError('Failed to connect wallet');
    }
  };

  const handleCreateBatch = async (batchData) => {
    try {
      setCreateLoading(true);
      setError('');
      setSuccess('');
      
      await contract.methods.createDrugBatch(
        batchData.drugName,
        batchData.manufacturer,
        batchData.manufacturingDate,
        batchData.expiryDate,
        batchData.quantity,
        batchData.location
      ).send({ from: currentAccount });
      
      setSuccess('Drug batch created successfully!');
      await loadDrugBatches(contract);
    } catch (error) {
      console.error('Error creating batch:', error);
      setError('Failed to create drug batch. Please try again.');
    } finally {
      setCreateLoading(false);
    }
  };

  const handleTransfer = async (batchId, recipient, location) => {
    try {
      setTransferLoading(true);
      setError('');
      setSuccess('');
      
      await contract.methods.transferDrugBatch(
        batchId,
        recipient,
        location
      ).send({ from: currentAccount });
      
      setSuccess('Drug batch transferred successfully!');
      setTransferModal({ isOpen: false, batchId: null });
      await loadDrugBatches(contract);
    } catch (error) {
      console.error('Error transferring batch:', error);
      setError('Failed to transfer drug batch. Please try again.');
    } finally {
      setTransferLoading(false);
    }
  };

  const handleViewHistory = async (batchId) => {
    try {
      const batch = drugBatches.find(b => b.batchId == batchId);
      const history = await contract.methods.getDrugBatchHistory(batchId).call();
      
      setHistoryModal({
        isOpen: true,
        batch,
        history
      });
    } catch (error) {
      console.error('Error loading batch history:', error);
      setError('Failed to load batch history');
    }
  };

  const canTransferBatch = (batch) => {
    return batch.currentOwner.toLowerCase() === currentAccount.toLowerCase() && 
           batch.status !== 4; // Not recalled
  };

  const getUserBatches = () => {
    return drugBatches.filter(batch => 
      batch.currentOwner.toLowerCase() === currentAccount.toLowerCase()
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
          <p>Connecting to blockchain...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar 
        currentAccount={currentAccount}
        userRole={userRole}
        onConnect={handleConnect}
      />
      
      <main className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        {error && (
          <Alert className="mb-6 border-red-200 bg-red-50">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription className="text-red-800">{error}</AlertDescription>
          </Alert>
        )}
        
        {success && (
          <Alert className="mb-6 border-green-200 bg-green-50">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription className="text-green-800">{success}</AlertDescription>
          </Alert>
        )}
        
        {!currentAccount ? (
          <div className="text-center py-12">
            <Package className="h-16 w-16 mx-auto text-gray-400 mb-4" />
            <h2 className="text-2xl font-bold text-gray-900 mb-2">
              Welcome to Drug Supply Chain
            </h2>
            <p className="text-gray-600 mb-6">
              Connect your wallet to start tracking drugs in the supply chain
            </p>
            <Button onClick={handleConnect} size="lg">
              Connect Wallet
            </Button>
          </div>
        ) : (
          <Tabs defaultValue="batches" className="space-y-6">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="batches" className="flex items-center gap-2">
                <Package className="w-4 h-4" />
                All Batches
              </TabsTrigger>
              <TabsTrigger value="my-batches" className="flex items-center gap-2">
                <Activity className="w-4 h-4" />
                My Batches
              </TabsTrigger>
              {userRole === 0 && (
                <TabsTrigger value="create" className="flex items-center gap-2">
                  <Package className="w-4 h-4" />
                  Create Batch
                </TabsTrigger>
              )}
            </TabsList>
            
            <TabsContent value="batches" className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-gray-900">All Drug Batches</h2>
                <div className="text-sm text-gray-600">
                  Total: {drugBatches.length} batches
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {drugBatches.map((batch) => (
                  <DrugBatchCard
                    key={batch.batchId}
                    batch={batch}
                    onViewHistory={handleViewHistory}
                    onTransfer={(batchId) => setTransferModal({ isOpen: true, batchId })}
                    canTransfer={canTransferBatch(batch)}
                    isExpired={batch.isExpired}
                  />
                ))}
              </div>
              
              {drugBatches.length === 0 && (
                <div className="text-center py-12">
                  <Package className="h-16 w-16 mx-auto text-gray-400 mb-4" />
                  <p className="text-gray-600">No drug batches found</p>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="my-batches" className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-gray-900">My Drug Batches</h2>
                <div className="text-sm text-gray-600">
                  Total: {getUserBatches().length} batches
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {getUserBatches().map((batch) => (
                  <DrugBatchCard
                    key={batch.batchId}
                    batch={batch}
                    onViewHistory={handleViewHistory}
                    onTransfer={(batchId) => setTransferModal({ isOpen: true, batchId })}
                    canTransfer={canTransferBatch(batch)}
                    isExpired={batch.isExpired}
                  />
                ))}
              </div>
              
              {getUserBatches().length === 0 && (
                <div className="text-center py-12">
                  <Package className="h-16 w-16 mx-auto text-gray-400 mb-4" />
                  <p className="text-gray-600">You don't own any drug batches</p>
                </div>
              )}
            </TabsContent>
            
            {userRole === 0 && (
              <TabsContent value="create" className="space-y-6">
                <h2 className="text-2xl font-bold text-gray-900 text-center mb-6">
                  Create New Drug Batch
                </h2>
                <DrugBatchForm 
                  onSubmit={handleCreateBatch}
                  isLoading={createLoading}
                />
              </TabsContent>
            )}
          </Tabs>
        )}
      </main>
      
      {/* Modals */}
      <TransferModal
        isOpen={transferModal.isOpen}
        onClose={() => setTransferModal({ isOpen: false, batchId: null })}
        onTransfer={handleTransfer}
        batchId={transferModal.batchId}
        participants={participants}
        isLoading={transferLoading}
      />
      
      <HistoryModal
        isOpen={historyModal.isOpen}
        onClose={() => setHistoryModal({ isOpen: false, batch: null, history: null })}
        batch={historyModal.batch}
        history={historyModal.history}
      />
    </div>
  );
}

export default App;

