import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, Send } from 'lucide-react';

const TransferModal = ({ 
  isOpen, 
  onClose, 
  onTransfer, 
  batchId, 
  participants, 
  isLoading 
}) => {
  const [formData, setFormData] = useState({
    recipient: '',
    location: ''
  });
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (!isOpen) {
      setFormData({ recipient: '', location: '' });
      setErrors({});
    }
  }, [isOpen]);

  const handleChange = (name, value) => {
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.recipient) {
      newErrors.recipient = 'Please select a recipient';
    }
    
    if (!formData.location.trim()) {
      newErrors.location = 'Location is required';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (validateForm()) {
      onTransfer(batchId, formData.recipient, formData.location);
    }
  };

  const getRoleLabel = (role) => {
    const roles = {
      0: 'Manufacturer',
      1: 'Distributor',
      2: 'Pharmacist',
      3: 'Consumer'
    };
    return roles[role] || 'Unknown';
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Send className="w-5 h-5" />
            Transfer Drug Batch
          </DialogTitle>
          <DialogDescription>
            Transfer batch #{batchId} to another participant in the supply chain
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="recipient">Recipient *</Label>
            <Select
              value={formData.recipient}
              onValueChange={(value) => handleChange('recipient', value)}
            >
              <SelectTrigger className={errors.recipient ? 'border-red-500' : ''}>
                <SelectValue placeholder="Select recipient" />
              </SelectTrigger>
              <SelectContent>
                {participants.map((participant) => (
                  <SelectItem key={participant.address} value={participant.address}>
                    <div className="flex flex-col">
                      <span className="font-medium">{participant.name}</span>
                      <span className="text-xs text-gray-500">
                        {getRoleLabel(participant.role)} • {participant.address.slice(0, 6)}...{participant.address.slice(-4)}
                      </span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.recipient && (
              <p className="text-sm text-red-500">{errors.recipient}</p>
            )}
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="location">Transfer Location *</Label>
            <Input
              id="location"
              value={formData.location}
              onChange={(e) => handleChange('location', e.target.value)}
              placeholder="e.g., California Warehouse"
              className={errors.location ? 'border-red-500' : ''}
            />
            {errors.location && (
              <p className="text-sm text-red-500">{errors.location}</p>
            )}
          </div>
          
          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Transferring...
                </>
              ) : (
                <>
                  <Send className="mr-2 h-4 w-4" />
                  Transfer
                </>
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default TransferModal;

