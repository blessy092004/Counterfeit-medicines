import React from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { formatDate } from '../utils/web3';
import { MapPin, Clock, User, Package } from 'lucide-react';

const HistoryModal = ({ isOpen, onClose, batch, history }) => {
  if (!batch || !history) return null;

  const getStepIcon = (index, total) => {
    if (index === 0) return <Package className="w-4 h-4 text-blue-500" />;
    if (index === total - 1) return <MapPin className="w-4 h-4 text-green-500" />;
    return <MapPin className="w-4 h-4 text-yellow-500" />;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Package className="w-5 h-5" />
            Batch History - {batch.drugName}
          </DialogTitle>
          <DialogDescription>
            Complete tracking history for batch #{batch.batchId}
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          {/* Batch Summary */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="font-semibold mb-2">Batch Information</h3>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div><span className="font-medium">Drug:</span> {batch.drugName}</div>
              <div><span className="font-medium">Manufacturer:</span> {batch.manufacturer}</div>
              <div><span className="font-medium">Quantity:</span> {batch.quantity} units</div>
              <div><span className="font-medium">Status:</span> 
                <Badge variant="outline" className="ml-1">
                  {batch.status === 0 ? 'Manufactured' : 
                   batch.status === 1 ? 'In Transit' :
                   batch.status === 2 ? 'Received' :
                   batch.status === 3 ? 'Dispensed' : 'Recalled'}
                </Badge>
              </div>
            </div>
          </div>
          
          {/* Timeline */}
          <div className="space-y-4">
            <h3 className="font-semibold">Supply Chain Timeline</h3>
            <div className="relative">
              {/* Timeline line */}
              <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-gray-200"></div>
              
              {history.locationHistory.map((location, index) => (
                <div key={index} className="relative flex items-start space-x-4 pb-6">
                  {/* Timeline dot */}
                  <div className="relative z-10 flex items-center justify-center w-12 h-12 bg-white border-2 border-gray-200 rounded-full">
                    {getStepIcon(index, history.locationHistory.length)}
                  </div>
                  
                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="bg-white border rounded-lg p-4 shadow-sm">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium text-gray-900">
                          {index === 0 ? 'Manufacturing' : `Transfer ${index}`}
                        </h4>
                        <Badge variant="outline" className="text-xs">
                          Step {index + 1}
                        </Badge>
                      </div>
                      
                      <div className="space-y-2 text-sm text-gray-600">
                        <div className="flex items-center gap-2">
                          <MapPin className="w-4 h-4" />
                          <span className="font-medium">Location:</span>
                          <span>{location}</span>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4" />
                          <span className="font-medium">Timestamp:</span>
                          <span>{formatDate(history.timestampHistory[index])}</span>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4" />
                          <span className="font-medium">Owner:</span>
                          <span className="font-mono text-xs">
                            {history.ownerHistory[index].slice(0, 6)}...{history.ownerHistory[index].slice(-4)}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Current Status */}
          <div className="bg-blue-50 p-4 rounded-lg">
            <h3 className="font-semibold mb-2 text-blue-900">Current Status</h3>
            <div className="text-sm text-blue-800">
              <div className="flex items-center gap-2 mb-1">
                <User className="w-4 h-4" />
                <span className="font-medium">Current Owner:</span>
                <span className="font-mono text-xs">
                  {batch.currentOwner.slice(0, 6)}...{batch.currentOwner.slice(-4)}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4" />
                <span className="font-medium">Last Location:</span>
                <span>{history.locationHistory[history.locationHistory.length - 1]}</span>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default HistoryModal;

