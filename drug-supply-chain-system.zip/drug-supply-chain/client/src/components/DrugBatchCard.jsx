import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { formatDate, DrugStatus } from '../utils/web3';
import { Package, Calendar, MapPin, User, AlertTriangle, Eye } from 'lucide-react';

const DrugBatchCard = ({ batch, onViewHistory, onTransfer, canTransfer, isExpired }) => {
  const getStatusColor = (status) => {
    switch (status) {
      case 0: return 'bg-blue-500';
      case 1: return 'bg-yellow-500';
      case 2: return 'bg-green-500';
      case 3: return 'bg-purple-500';
      case 4: return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusVariant = (status) => {
    switch (status) {
      case 0: return 'default';
      case 1: return 'secondary';
      case 2: return 'outline';
      case 3: return 'secondary';
      case 4: return 'destructive';
      default: return 'secondary';
    }
  };

  return (
    <Card className={`w-full ${isExpired ? 'border-red-200 bg-red-50' : ''}`}>
      <CardHeader>
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Package className="w-5 h-5" />
              {batch.drugName}
              {isExpired && (
                <Badge variant="destructive" className="ml-2">
                  <AlertTriangle className="w-3 h-3 mr-1" />
                  Expired
                </Badge>
              )}
            </CardTitle>
            <CardDescription>Batch ID: #{batch.batchId}</CardDescription>
          </div>
          <Badge variant={getStatusVariant(batch.status)}>
            <div className={`w-2 h-2 rounded-full ${getStatusColor(batch.status)} mr-2`}></div>
            {DrugStatus[batch.status]}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <User className="w-4 h-4" />
              <span className="font-medium">Manufacturer:</span>
              <span>{batch.manufacturer}</span>
            </div>
            
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <Package className="w-4 h-4" />
              <span className="font-medium">Quantity:</span>
              <span>{batch.quantity} units</span>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <Calendar className="w-4 h-4" />
              <span className="font-medium">Manufactured:</span>
              <span>{formatDate(batch.manufacturingDate)}</span>
            </div>
            
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <Calendar className="w-4 h-4" />
              <span className="font-medium">Expires:</span>
              <span className={isExpired ? 'text-red-600 font-medium' : ''}>
                {formatDate(batch.expiryDate)}
              </span>
            </div>
          </div>
          
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <User className="w-4 h-4" />
            <span className="font-medium">Current Owner:</span>
            <span className="font-mono text-xs">
              {batch.currentOwner.slice(0, 6)}...{batch.currentOwner.slice(-4)}
            </span>
          </div>
          
          <div className="flex gap-2 pt-4">
            <Button
              variant="outline"
              size="sm"
              onClick={() => onViewHistory(batch.batchId)}
              className="flex items-center gap-1"
            >
              <Eye className="w-4 h-4" />
              View History
            </Button>
            
            {canTransfer && batch.status !== 4 && (
              <Button
                size="sm"
                onClick={() => onTransfer(batch.batchId)}
                className="flex items-center gap-1"
              >
                <MapPin className="w-4 h-4" />
                Transfer
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default DrugBatchCard;

