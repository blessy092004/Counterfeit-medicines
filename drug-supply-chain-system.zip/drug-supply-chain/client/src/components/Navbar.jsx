import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { getCurrentAccount, Role } from '../utils/web3';
import { Package, Users, Activity, Shield } from 'lucide-react';

const Navbar = ({ currentAccount, userRole, onConnect }) => {
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    setIsConnected(!!currentAccount);
  }, [currentAccount]);

  const getRoleIcon = (role) => {
    switch (role) {
      case 0: return <Package className="w-4 h-4" />;
      case 1: return <Activity className="w-4 h-4" />;
      case 2: return <Shield className="w-4 h-4" />;
      default: return <Users className="w-4 h-4" />;
    }
  };

  const getRoleBadgeVariant = (role) => {
    switch (role) {
      case 0: return 'default';
      case 1: return 'secondary';
      case 2: return 'outline';
      default: return 'destructive';
    }
  };

  return (
    <nav className="bg-white shadow-sm border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <Shield className="h-8 w-8 text-blue-600" />
              <span className="ml-2 text-xl font-bold text-gray-900">
                Drug Supply Chain
              </span>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            {isConnected ? (
              <div className="flex items-center space-x-3">
                <Badge variant={getRoleBadgeVariant(userRole)} className="flex items-center gap-1">
                  {getRoleIcon(userRole)}
                  {Role[userRole] || 'Unknown'}
                </Badge>
                <div className="text-sm text-gray-600">
                  {currentAccount ? `${currentAccount.slice(0, 6)}...${currentAccount.slice(-4)}` : ''}
                </div>
              </div>
            ) : (
              <Button onClick={onConnect} variant="outline">
                Connect Wallet
              </Button>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;

