import Web3 from 'web3';
import DrugSupplyChainContract from '../build/contracts/DrugSupplyChain.json';

let web3;
let contract;

// Initialize Web3
export const initWeb3 = async () => {
  try {
    // Check if MetaMask is installed
    if (window.ethereum) {
      web3 = new Web3(window.ethereum);
      await window.ethereum.request({ method: 'eth_requestAccounts' });
    } else if (window.web3) {
      web3 = new Web3(window.web3.currentProvider);
    } else {
      // Fallback to local blockchain
      web3 = new Web3(new Web3.providers.HttpProvider('http://localhost:8545'));
    }
    
    return web3;
  } catch (error) {
    console.error('Error initializing Web3:', error);
    throw error;
  }
};

// Get contract instance
export const getContract = async () => {
  if (!web3) {
    await initWeb3();
  }
  
  try {
    const networkId = await web3.eth.net.getId();
    const deployedNetwork = DrugSupplyChainContract.networks[networkId];
    
    if (!deployedNetwork) {
      throw new Error('Contract not deployed on current network');
    }
    
    contract = new web3.eth.Contract(
      DrugSupplyChainContract.abi,
      deployedNetwork.address
    );
    
    return contract;
  } catch (error) {
    console.error('Error getting contract:', error);
    throw error;
  }
};

// Get current account
export const getCurrentAccount = async () => {
  if (!web3) {
    await initWeb3();
  }
  
  const accounts = await web3.eth.getAccounts();
  return accounts[0];
};

// Get all accounts
export const getAccounts = async () => {
  if (!web3) {
    await initWeb3();
  }
  
  return await web3.eth.getAccounts();
};

// Convert timestamp to readable date
export const formatDate = (timestamp) => {
  return new Date(timestamp * 1000).toLocaleString();
};

// Drug status enum mapping
export const DrugStatus = {
  0: 'Manufactured',
  1: 'In Transit',
  2: 'Received',
  3: 'Dispensed',
  4: 'Recalled'
};

// Role enum mapping
export const Role = {
  0: 'Manufacturer',
  1: 'Distributor',
  2: 'Pharmacist',
  3: 'Consumer'
};

export { web3 };

