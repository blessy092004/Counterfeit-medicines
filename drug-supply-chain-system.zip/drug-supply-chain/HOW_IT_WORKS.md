# Drug Supply Chain Management System - How It Works

## Table of Contents
1. [System Overview](#system-overview)
2. [Architecture Components](#architecture-components)
3. [Blockchain Integration](#blockchain-integration)
4. [User Workflows](#user-workflows)
5. [Security Features](#security-features)
6. [Data Flow](#data-flow)
7. [Smart Contract Logic](#smart-contract-logic)
8. [Frontend Functionality](#frontend-functionality)

## System Overview

The Drug Supply Chain Management System is a blockchain-based application designed to combat counterfeit medications by providing complete traceability and transparency throughout the pharmaceutical supply chain. The system leverages Ethereum blockchain technology to create an immutable record of drug manufacturing, distribution, and dispensing processes.

### Core Problem Addressed

Counterfeit medications represent a significant global health threat, with studies indicating that nearly 30% of medicines in developing countries may be fake. Traditional supply chain systems lack transparency and are vulnerable to tampering, making it difficult to verify drug authenticity and track the complete journey from manufacturer to consumer.

### Solution Approach

This system addresses these challenges by:

**Immutable Record Keeping:** All drug batch information and transfers are recorded on the blockchain, creating a permanent and tamper-proof audit trail.

**Complete Traceability:** Every drug batch can be traced from its manufacturing origin through all distribution points to its final destination.

**Role-Based Access Control:** Different participants in the supply chain have specific permissions and responsibilities, ensuring proper workflow and security.

**Real-Time Verification:** Stakeholders can instantly verify drug authenticity and check for recalls or expiry issues.

**Decentralized Trust:** The blockchain eliminates the need for a central authority, allowing all participants to trust the system without relying on a single entity.

## Architecture Components

### Three-Tier Architecture

The system follows a three-tier architecture pattern:

**Presentation Layer (React Frontend)**
- User interface for different stakeholders
- Web-based application accessible through browsers
- Responsive design supporting desktop and mobile devices
- Real-time updates and notifications

**Business Logic Layer (Smart Contracts)**
- Ethereum smart contracts written in Solidity
- Implements all business rules and workflows
- Handles access control and permissions
- Manages state transitions and validations

**Data Layer (Blockchain)**
- Ethereum blockchain serves as the database
- Immutable storage of all transactions and state changes
- Distributed across network nodes for redundancy
- Cryptographically secured and verified

### Technology Stack

**Blockchain Platform:** Ethereum
- Chosen for its mature ecosystem and smart contract capabilities
- Provides decentralized execution environment
- Supports complex business logic implementation
- Wide adoption and community support

**Smart Contract Language:** Solidity
- Industry standard for Ethereum smart contracts
- Object-oriented programming with inheritance
- Built-in security features and access controls
- Extensive library ecosystem (OpenZeppelin)

**Frontend Framework:** React.js
- Component-based architecture for maintainability
- Virtual DOM for efficient rendering
- Large ecosystem of libraries and tools
- Excellent developer experience

**Web3 Integration:** Web3.js
- JavaScript library for blockchain interaction
- Handles wallet connections and transactions
- Provides contract abstraction layer
- Event listening and real-time updates

**Development Tools:**
- Truffle: Smart contract development framework
- Ganache: Local blockchain for development
- Vite: Fast build tool and development server
- Tailwind CSS: Utility-first styling framework

## Blockchain Integration

### Smart Contract Architecture

The system uses a single main smart contract (`DrugSupplyChain.sol`) that manages all functionality:

**Contract Inheritance:**
```solidity
contract DrugSupplyChain is Ownable
```
- Inherits from OpenZeppelin's `Ownable` contract
- Provides admin functionality for system management
- Ensures secure ownership transfer if needed

**State Management:**
- Uses mappings for efficient data storage
- Implements counters for unique ID generation
- Maintains participant registry and permissions
- Stores complete batch history and current state

**Event System:**
- Emits events for all significant state changes
- Enables real-time frontend updates
- Provides audit trail for external systems
- Supports integration with monitoring tools

### Blockchain Benefits

**Immutability:** Once data is recorded on the blockchain, it cannot be altered or deleted, ensuring the integrity of the supply chain records.

**Transparency:** All authorized participants can view the complete history of any drug batch, promoting accountability and trust.

**Decentralization:** No single point of failure or control, reducing risks associated with centralized systems.

**Cryptographic Security:** All transactions are cryptographically signed and verified, preventing unauthorized modifications.

**Consensus Mechanism:** Network consensus ensures all participants agree on the current state of the system.

## User Workflows

### Manufacturer Workflow

**1. Registration Process:**
- System administrator registers manufacturer account
- Manufacturer receives blockchain address and credentials
- Account is assigned manufacturer role (Role.Manufacturer)
- Manufacturer gains access to batch creation functionality

**2. Drug Batch Creation:**
```
Manufacturer Input → Smart Contract Validation → Blockchain Storage → Event Emission
```
- Manufacturer fills out batch creation form
- System validates all required fields and business rules
- Smart contract creates new batch with unique ID
- Batch information stored immutably on blockchain
- DrugBatchCreated event emitted for real-time updates

**3. Batch Transfer to Distributor:**
```
Select Batch → Choose Distributor → Confirm Transfer → Blockchain Transaction
```
- Manufacturer selects batch from their inventory
- System displays list of registered distributors
- Transfer details (recipient, location) are specified
- Smart contract validates ownership and permissions
- Ownership transferred and history updated

### Distributor Workflow

**1. Receiving Batches:**
- Distributor automatically receives batches transferred to them
- Batch status changes to "In Transit" during transfer
- Distributor updates status to "Received" upon physical receipt
- Location and timestamp recorded on blockchain

**2. Inventory Management:**
- View all received batches in "My Batches" section
- Monitor batch status and expiry dates
- Track batch history and previous owners
- Manage multiple batches from different manufacturers

**3. Transfer to Pharmacist:**
- Similar process to manufacturer-distributor transfer
- Select pharmacist from registered participants
- Specify delivery location and confirm transfer
- Blockchain records complete transaction details

### Pharmacist Workflow

**1. Batch Reception:**
- Receive batches from distributors
- Verify batch authenticity using blockchain records
- Update status to "Received" in the system
- Check for any recalls or expiry issues

**2. Drug Dispensing:**
- Update batch status to "Dispensed" when medication is given to patients
- Record dispensing location and timestamp
- Maintain inventory levels and tracking
- Ensure compliance with regulatory requirements

**3. Patient Verification:**
- Provide batch information to patients for verification
- Enable patients to check drug authenticity
- Support regulatory compliance and reporting
- Maintain complete audit trail

### Consumer/Patient Workflow

**1. Drug Verification:**
- Access batch history using batch ID or QR code
- View complete supply chain journey
- Verify manufacturer authenticity
- Check for recalls or safety alerts

**2. Authenticity Confirmation:**
- Compare physical drug packaging with blockchain records
- Verify expiry dates and manufacturing information
- Report suspicious or counterfeit products
- Access educational resources about drug safety

## Security Features

### Access Control System

**Role-Based Permissions:**
```solidity
enum Role { Manufacturer, Distributor, Pharmacist, Consumer }
```
- Each participant assigned specific role
- Functions restricted based on role permissions
- Prevents unauthorized actions and data access
- Supports principle of least privilege

**Modifier-Based Security:**
```solidity
modifier onlyAuthorized() {
    require(authorizedParticipants[msg.sender], "Not authorized");
    _;
}

modifier onlyManufacturer() {
    require(participants[msg.sender].role == Role.Manufacturer, "Only manufacturer");
    _;
}
```

**Ownership Validation:**
- Only current batch owner can transfer or update status
- Prevents unauthorized batch modifications
- Ensures proper chain of custody
- Maintains data integrity

### Cryptographic Security

**Digital Signatures:**
- All transactions signed with private keys
- Prevents impersonation and unauthorized access
- Ensures non-repudiation of actions
- Supports legal compliance requirements

**Hash-Based Integrity:**
- All data cryptographically hashed
- Tampering detection through hash verification
- Immutable record creation
- Chain of trust establishment

**Address-Based Identity:**
- Ethereum addresses serve as unique identifiers
- Public-private key cryptography
- Secure authentication without passwords
- Decentralized identity management

### Data Protection

**On-Chain vs Off-Chain Data:**
- Critical tracking data stored on blockchain
- Sensitive personal information kept off-chain
- Compliance with privacy regulations
- Balanced approach to transparency and privacy

**Encryption Considerations:**
- Blockchain data is publicly readable
- Sensitive data encrypted before storage
- Key management for authorized access
- Privacy-preserving techniques where needed

## Data Flow

### Batch Creation Flow

```
1. Manufacturer Input
   ↓
2. Frontend Validation
   ↓
3. Web3 Transaction Creation
   ↓
4. MetaMask/Wallet Signing
   ↓
5. Blockchain Network Propagation
   ↓
6. Smart Contract Execution
   ↓
7. State Update and Event Emission
   ↓
8. Frontend Update via Event Listening
```

### Transfer Flow

```
1. Current Owner Initiates Transfer
   ↓
2. Recipient Selection and Validation
   ↓
3. Transfer Details Specification
   ↓
4. Smart Contract Permission Check
   ↓
5. Ownership Transfer Execution
   ↓
6. History Update and Status Change
   ↓
7. Event Emission for All Parties
   ↓
8. Real-Time UI Updates
```

### History Retrieval Flow

```
1. User Requests Batch History
   ↓
2. Frontend Calls Smart Contract
   ↓
3. Contract Returns Historical Data
   ↓
4. Data Processing and Formatting
   ↓
5. Timeline Visualization
   ↓
6. User Interface Display
```

## Smart Contract Logic

### Core Data Structures

**DrugBatch Struct:**
```solidity
struct DrugBatch {
    uint256 batchId;           // Unique identifier
    string drugName;           // Medication name
    string manufacturer;       // Manufacturing company
    uint256 manufacturingDate; // Production timestamp
    uint256 expiryDate;       // Expiration timestamp
    uint256 quantity;         // Number of units
    DrugStatus status;        // Current status
    address currentOwner;     // Current owner address
    string[] locationHistory; // Location tracking
    uint256[] timestampHistory; // Time tracking
    address[] ownerHistory;   // Ownership tracking
}
```

**Participant Struct:**
```solidity
struct Participant {
    address participantAddress; // Blockchain address
    string name;               // Organization name
    string location;           // Physical location
    Role role;                // Participant role
    bool isActive;            // Account status
}
```

### Key Functions

**createDrugBatch():**
- Validates manufacturer permissions
- Generates unique batch ID
- Initializes batch with provided data
- Records initial location and ownership
- Emits creation event

**transferDrugBatch():**
- Validates current ownership
- Checks recipient authorization
- Updates ownership and status
- Appends to history arrays
- Emits transfer event

**updateDrugStatus():**
- Validates owner permissions
- Updates batch status
- Records timestamp
- Emits status change event

**getDrugBatch():**
- Returns batch information
- Public view function
- No gas cost for reading
- Supports frontend queries

**getDrugBatchHistory():**
- Returns complete history arrays
- Enables timeline reconstruction
- Supports audit and compliance
- Public access for transparency

### Business Logic Implementation

**Status Transitions:**
```
Manufactured → In Transit → Received → Dispensed
                    ↓
                 Recalled (from any status)
```

**Validation Rules:**
- Only manufacturers can create batches
- Only current owner can transfer batches
- Expiry date must be after manufacturing date
- Quantity must be positive
- All participants must be registered and active

**Error Handling:**
- Comprehensive require statements
- Descriptive error messages
- Graceful failure modes
- Gas optimization considerations

## Frontend Functionality

### Component Architecture

**App.jsx (Main Controller):**
- Manages global application state
- Handles Web3 initialization
- Coordinates component interactions
- Implements error handling and notifications

**Navbar.jsx (Navigation):**
- Displays user connection status
- Shows current role and account
- Provides wallet connection interface
- Responsive design for mobile devices

**DrugBatchForm.jsx (Data Entry):**
- Collects batch creation data
- Implements client-side validation
- Handles form submission to blockchain
- Provides user feedback and loading states

**DrugBatchCard.jsx (Data Display):**
- Presents batch information in card format
- Shows status with color coding
- Provides action buttons for interactions
- Highlights expired or recalled batches

**Modal Components:**
- TransferModal: Handles batch transfers
- HistoryModal: Displays complete batch timeline
- Responsive design with proper accessibility

### State Management

**React Hooks Usage:**
```javascript
const [web3, setWeb3] = useState(null);
const [contract, setContract] = useState(null);
const [currentAccount, setCurrentAccount] = useState('');
const [drugBatches, setDrugBatches] = useState([]);
const [participants, setParticipants] = useState([]);
```

**Effect Hooks for Lifecycle:**
- Component mounting and unmounting
- Web3 connection management
- Event listener setup and cleanup
- Data synchronization with blockchain

### Real-Time Updates

**Event Listening:**
```javascript
contract.events.DrugBatchCreated()
  .on('data', (event) => {
    // Update UI with new batch
    loadDrugBatches();
  });
```

**Automatic Refresh:**
- Listen for blockchain events
- Update UI without page refresh
- Maintain data consistency
- Provide real-time user experience

### User Experience Features

**Loading States:**
- Show progress during blockchain transactions
- Disable buttons during processing
- Provide clear feedback to users
- Handle transaction failures gracefully

**Error Handling:**
- Display user-friendly error messages
- Provide troubleshooting guidance
- Log technical details for debugging
- Maintain application stability

**Responsive Design:**
- Mobile-first approach
- Touch-friendly interfaces
- Adaptive layouts for different screen sizes
- Consistent experience across devices

### Integration Points

**Web3 Connection:**
- Automatic provider detection
- MetaMask integration
- Fallback to local blockchain
- Connection status monitoring

**Contract Interaction:**
- Function call abstraction
- Transaction signing workflow
- Gas estimation and optimization
- Error handling and retry logic

**Data Formatting:**
- Timestamp conversion to readable dates
- Address truncation for display
- Status enum to string mapping
- Number formatting for quantities

This comprehensive system provides a robust, secure, and user-friendly solution for drug supply chain management, leveraging blockchain technology to ensure transparency, traceability, and authenticity throughout the pharmaceutical distribution process.

