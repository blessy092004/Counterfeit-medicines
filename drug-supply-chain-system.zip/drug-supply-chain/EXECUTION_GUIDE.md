
# Drug Supply Chain Management System - Execution Guide

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Installation](#installation)
3. [Blockchain Setup](#blockchain-setup)
4. [Smart Contract Deployment](#smart-contract-deployment)
5. [Frontend Setup](#frontend-setup)
6. [Running the Application](#running-the-application)
7. [User Guide](#user-guide)
8. [Troubleshooting](#troubleshooting)

## Prerequisites

Before running the Drug Supply Chain Management System, ensure you have the following software installed on your system:

### Required Software

**Node.js and npm**
- Node.js version 18.0.0 or higher
- npm (Node Package Manager) comes bundled with Node.js
- Download from: https://nodejs.org/

**Git**
- Required for cloning repositories and version control
- Download from: https://git-scm.com/

**MetaMask Browser Extension (Optional but Recommended)**
- Browser extension for interacting with Ethereum blockchain
- Download from: https://metamask.io/
- Supported browsers: Chrome, Firefox, Edge, Safari

### System Requirements

**Operating System**
- Windows 10/11, macOS 10.15+, or Linux (Ubuntu 18.04+)

**Hardware**
- Minimum 4GB RAM
- At least 2GB free disk space
- Internet connection for downloading dependencies

**Browser Requirements**
- Modern web browser with JavaScript enabled
- Chrome 90+, Firefox 88+, Safari 14+, or Edge 90+

## Installation

### Step 1: Extract the Project Files

Extract the provided zip file to your desired location:

```bash
# On Windows (using Command Prompt)
cd C:\your\desired\path
# Extract the zip file using Windows Explorer or 7-Zip

# On macOS/Linux
cd /your/desired/path
unzip drug-supply-chain.zip
cd drug-supply-chain
```

### Step 2: Install Dependencies

The project consists of two main parts: the blockchain smart contracts and the React frontend. You need to install dependencies for both.

**Install Root Dependencies (Blockchain)**

```bash
# Navigate to the project root
cd drug-supply-chain

# Install blockchain dependencies
npm install
```

This will install the following key dependencies:
- Truffle: Framework for Ethereum smart contract development
- Ganache CLI: Local blockchain for development
- OpenZeppelin Contracts: Secure smart contract library
- Web3.js: JavaScript library for interacting with Ethereum

**Install Frontend Dependencies**

```bash
# Navigate to the client directory
cd client

# Install frontend dependencies using pnpm (recommended)
pnpm install

# Alternative: use npm if pnpm is not available
npm install
```

This will install:
- React: Frontend framework
- Vite: Build tool and development server
- Tailwind CSS: Utility-first CSS framework
- shadcn/ui: Component library
- Web3.js: Blockchain interaction library
- Lucide React: Icon library

### Step 3: Verify Installation

Verify that all dependencies are installed correctly:

```bash
# Check Node.js version
node --version

# Check npm version
npm --version

# Check if Truffle is installed
npx truffle version

# Check if pnpm is available (in client directory)
cd client
pnpm --version
```

## Blockchain Setup

### Step 1: Start Local Blockchain

The system uses Ganache CLI to create a local Ethereum blockchain for development and testing.

```bash
# Navigate to project root
cd drug-supply-chain

# Start Ganache with predefined accounts
npx ganache-cli --deterministic --accounts 10 --host 0.0.0.0 --port 8545
```

**Ganache Configuration Explained:**
- `--deterministic`: Creates the same accounts every time for consistent testing
- `--accounts 10`: Creates 10 test accounts with 100 ETH each
- `--host 0.0.0.0`: Allows connections from any IP address
- `--port 8545`: Standard Ethereum RPC port

**Important:** Keep this terminal window open while using the application. The blockchain will stop if you close this terminal.

### Step 2: Configure MetaMask (Optional)

If you want to use MetaMask for a more realistic blockchain experience:

1. **Install MetaMask** browser extension from https://metamask.io/
2. **Create or import a wallet** following MetaMask's setup wizard
3. **Add Local Network:**
   - Click on the network dropdown (usually shows "Ethereum Mainnet")
   - Select "Add Network" or "Custom RPC"
   - Enter the following details:
     - Network Name: `Local Ganache`
     - New RPC URL: `http://localhost:8545`
     - Chain ID: `1337` (or the chain ID shown in Ganache output)
     - Currency Symbol: `ETH`
     - Block Explorer URL: (leave empty)

4. **Import Test Accounts:**
   - Copy private keys from Ganache output
   - In MetaMask, click account icon → Import Account
   - Paste the private key and import

### Step 3: Verify Blockchain Connection

Test the blockchain connection:

```bash
# In a new terminal, navigate to project root
cd drug-supply-chain

# Test connection using Web3
node -e "
import('web3').then(({ default: Web3 }) => {
  const web3 = new Web3('http://localhost:8545');
  return web3.eth.getAccounts();
}).then(accounts => {
  console.log('✅ Connected to blockchain');
  console.log('Available accounts:', accounts.length);
  console.log('First account:', accounts[0]);
}).catch(err => {
  console.error('❌ Blockchain connection failed:', err.message);
});
"
```

Expected output:
```
✅ Connected to blockchain
Available accounts: 10
First account: 0x90F8bf6A479f320ead074411a4B0e7944Ea8c9C1
```

## Smart Contract Deployment

### Step 1: Compile Smart Contracts

```bash
# Navigate to project root
cd drug-supply-chain

# Compile the smart contracts
npx truffle compile
```

Expected output:
```
Compiling your contracts...
===========================
> Compiling ./contracts/DrugSupplyChain.sol
> Artifacts written to /path/to/build/contracts
> Compiled successfully using solc: 0.8.19
```

### Step 2: Deploy Smart Contracts

```bash
# Deploy contracts to local blockchain
npx truffle migrate --network development
```

Expected output:
```
Starting migrations...
======================
> Network name:    'development'
> Network id:      1337
> Block gas limit: 30000000

2_deploy_contracts.js
=====================
   Deploying 'DrugSupplyChain'
   ---------------------------
   > transaction hash:    0x...
   > contract address:    0x...
   > block number:        1
   > account:             0x90F8bf6A479f320ead074411a4B0e7944Ea8c9C1
   > balance:             99.96...
   > gas used:            1813798
   > gas price:           20 gwei
   > value sent:          0 ETH
   > total cost:          0.036... ETH

   > Saving artifacts
   -------------------------------------
   > Total cost:          0.036... ETH

Summary
=======
> Total deployments:   1
> Final cost:          0.036... ETH
```

**Important:** Note the contract address from the deployment output. This address is automatically saved in the build artifacts and used by the frontend.

### Step 3: Copy Contract Artifacts

The frontend needs access to the compiled contract artifacts:

```bash
# Copy build artifacts to frontend
cp -r build client/src/
```

### Step 4: Run Smart Contract Tests (Optional)

Verify that the smart contracts work correctly:

```bash
# Run the test suite
npx truffle test
```

Expected output should show all tests passing:
```
Contract: DrugSupplyChain
  Participant Registration
    ✓ should register a manufacturer
    ✓ should register a distributor
    ✓ should register a pharmacist
  Drug Batch Creation
    ✓ should create a new drug batch
  Drug Batch Transfer
    ✓ should transfer drug batch to distributor
    ✓ should maintain transfer history
  Drug Status Updates
    ✓ should update drug status
    ✓ should allow owner to recall drug batch
  Drug Expiry Check
    ✓ should correctly identify expired drugs

  9 passing (2s)
```

## Frontend Setup

### Step 1: Navigate to Client Directory

```bash
cd client
```

### Step 2: Verify Dependencies

Ensure all frontend dependencies are installed:

```bash
# Check if node_modules exists and has content
ls node_modules | head -10

# If dependencies are missing, install them
pnpm install
# or
npm install
```

### Step 3: Configure Environment (Optional)

Create a `.env` file in the client directory for environment-specific configuration:

```bash
# Create .env file
touch .env

# Add configuration (optional)
echo "VITE_BLOCKCHAIN_URL=http://localhost:8545" >> .env
echo "VITE_NETWORK_ID=1337" >> .env
```

## Running the Application

### Step 1: Start the Development Server

```bash
# Navigate to client directory
cd client

# Start the React development server
pnpm run dev --host
# or
npm run dev -- --host
```

Expected output:
```
> client@0.0.0 dev
> vite --host

  VITE v6.3.5  ready in 673 ms

  ➜  Local:   http://localhost:5173/
  ➜  Network: http://192.168.1.100:5173/
  ➜  press h + enter to show help
```

### Step 2: Access the Application

Open your web browser and navigate to:
- **Local access:** http://localhost:5173/
- **Network access:** Use the network URL shown in the terminal

### Step 3: Initial Setup

When you first access the application:

1. **Connect Wallet:** Click the "Connect Wallet" button in the top-right corner
2. **MetaMask Integration:** If using MetaMask, approve the connection request
3. **Account Selection:** The application will automatically detect your account and role

### Step 4: Register Participants (Admin Only)

The system requires participants to be registered before they can use the application. The contract deployer (first account) has admin privileges.

**Using Truffle Console (Recommended for Initial Setup):**

```bash
# In a new terminal, navigate to project root
cd drug-supply-chain

# Open Truffle console
npx truffle console --network development

# In the console, register participants
truffle(development)> let contract = await DrugSupplyChain.deployed()
truffle(development)> let accounts = await web3.eth.getAccounts()

# Register a manufacturer
truffle(development)> await contract.registerParticipant(
  accounts[1], 
  "ABC Pharmaceuticals", 
  "New York", 
  0  // Role.Manufacturer
)

# Register a distributor
truffle(development)> await contract.registerParticipant(
  accounts[2], 
  "XYZ Distribution", 
  "California", 
  1  // Role.Distributor
)

# Register a pharmacist
truffle(development)> await contract.registerParticipant(
  accounts[3], 
  "City Pharmacy", 
  "Texas", 
  2  // Role.Pharmacist
)

# Exit console
truffle(development)> .exit
```

## User Guide

### Understanding User Roles

The system supports four types of users:

**1. Manufacturer (Role 0)**
- Can create new drug batches
- Can transfer batches to distributors
- Can update batch status
- Can view all batches and their own batches

**2. Distributor (Role 1)**
- Can receive batches from manufacturers
- Can transfer batches to pharmacists
- Can update batch status
- Can view all batches and their own batches

**3. Pharmacist (Role 2)**
- Can receive batches from distributors
- Can dispense drugs to consumers
- Can update batch status
- Can view all batches and their own batches

**4. Consumer (Role 3)**
- Can view drug batch history for verification
- Cannot create or transfer batches

### Using the Application

#### For Manufacturers

**Creating a New Drug Batch:**

1. **Access Creation Form:** Click on the "Create Batch" tab (only visible to manufacturers)
2. **Fill Required Information:**
   - Drug Name: Enter the name of the medication
   - Manufacturer: Your company name
   - Manufacturing Date: When the batch was produced
   - Expiry Date: When the batch expires
   - Quantity: Number of units in the batch
   - Location: Manufacturing facility location

3. **Submit:** Click "Create Drug Batch" button
4. **Confirm Transaction:** If using MetaMask, approve the transaction
5. **Verification:** The new batch will appear in your "My Batches" tab

**Transferring a Batch:**

1. **Find Your Batch:** Go to "My Batches" tab
2. **Initiate Transfer:** Click "Transfer" button on the desired batch
3. **Select Recipient:** Choose from registered distributors
4. **Enter Location:** Specify the transfer destination
5. **Confirm:** Click "Transfer" and approve the transaction

#### For Distributors and Pharmacists

**Receiving Batches:**
- Batches transferred to you automatically appear in your "My Batches" tab
- Status changes to "In Transit" during transfer
- Update status to "Received" when you physically receive the batch

**Transferring Batches:**
- Similar process to manufacturers
- Distributors transfer to pharmacists
- Pharmacists can dispense to consumers

#### For All Users

**Viewing Batch History:**

1. **Find Any Batch:** In "All Batches" or "My Batches" tab
2. **Click "View History":** Opens detailed timeline
3. **Review Information:**
   - Complete supply chain journey
   - All previous owners
   - Location history
   - Timestamps for each transfer
   - Current status and owner

**Checking Drug Authenticity:**
- Expired drugs are highlighted in red
- Recalled drugs show special status
- Complete traceability from manufacturer to current location
- Immutable blockchain records prevent tampering

### Application Features

#### Dashboard Overview

**Navigation Bar:**
- Application title and logo
- User role badge
- Connected wallet address
- Connect/disconnect wallet button

**Main Tabs:**
- **All Batches:** View all drug batches in the system
- **My Batches:** View batches you currently own
- **Create Batch:** Create new batches (manufacturers only)

#### Batch Information Cards

Each drug batch is displayed as a card containing:
- Drug name and batch ID
- Current status with color-coded indicator
- Manufacturer information
- Manufacturing and expiry dates
- Current quantity
- Current owner address
- Action buttons (View History, Transfer)

#### Status Indicators

**Color-Coded Status System:**
- 🔵 **Blue:** Manufactured (newly created)
- 🟡 **Yellow:** In Transit (being transferred)
- 🟢 **Green:** Received (successfully delivered)
- 🟣 **Purple:** Dispensed (given to consumer)
- 🔴 **Red:** Recalled (removed from circulation)

#### Transfer Modal

**Transfer Process:**
1. Select recipient from dropdown list
2. Enter destination location
3. Confirm transfer details
4. Submit blockchain transaction
5. Wait for confirmation

#### History Modal

**Detailed Timeline View:**
- Step-by-step journey visualization
- Location and timestamp for each step
- Owner information at each stage
- Current status summary
- Complete audit trail

## Troubleshooting

### Common Issues and Solutions

#### Blockchain Connection Issues

**Problem:** "Failed to connect to blockchain"
**Solutions:**
1. Ensure Ganache is running on port 8545
2. Check if the port is blocked by firewall
3. Restart Ganache with correct parameters
4. Verify network configuration in truffle-config.js

**Problem:** "Contract not deployed on current network"
**Solutions:**
1. Run `npx truffle migrate --network development`
2. Ensure Ganache is running before deployment
3. Check if contract artifacts exist in build/contracts/
4. Copy artifacts to client/src/build/ directory

#### MetaMask Issues

**Problem:** MetaMask not connecting
**Solutions:**
1. Refresh the browser page
2. Check if MetaMask is unlocked
3. Ensure correct network is selected
4. Clear MetaMask cache and reconnect

**Problem:** Transaction failures
**Solutions:**
1. Check if you have sufficient ETH for gas fees
2. Increase gas limit in MetaMask
3. Reset MetaMask account if nonce is out of sync
4. Ensure you're connected to the correct network

#### Frontend Issues

**Problem:** React development server won't start
**Solutions:**
1. Check if port 5173 is available
2. Clear node_modules and reinstall dependencies
3. Update Node.js to latest LTS version
4. Run `pnpm install` or `npm install` again

**Problem:** Components not loading correctly
**Solutions:**
1. Clear browser cache and cookies
2. Check browser console for JavaScript errors
3. Ensure all dependencies are installed
4. Restart the development server

#### Smart Contract Issues

**Problem:** "Only manufacturer can perform this action"
**Solutions:**
1. Ensure you're using the correct account
2. Register your account as a manufacturer
3. Check if your account is authorized
4. Use the admin account to register participants

**Problem:** "Batch does not exist"
**Solutions:**
1. Verify the batch ID is correct
2. Ensure the batch was created successfully
3. Check if you're connected to the correct network
4. Refresh the application to reload batch data

### Performance Optimization

#### For Better Performance

**Blockchain Optimization:**
- Use appropriate gas limits for transactions
- Batch multiple operations when possible
- Monitor gas prices and adjust accordingly
- Keep Ganache running consistently

**Frontend Optimization:**
- Close unused browser tabs
- Clear browser cache regularly
- Use latest version of supported browsers
- Ensure stable internet connection

**System Resources:**
- Allocate sufficient RAM for Node.js processes
- Close unnecessary applications
- Monitor disk space usage
- Keep system updated

### Getting Help

#### Log Files and Debugging

**Ganache Logs:**
```bash
# View Ganache output
tail -f ganache.log
```

**React Development Logs:**
```bash
# View React server logs
tail -f react.log
```

**Browser Console:**
1. Open browser developer tools (F12)
2. Check Console tab for JavaScript errors
3. Check Network tab for failed requests
4. Check Application tab for storage issues

#### Support Resources

**Documentation:**
- Truffle Documentation: https://trufflesuite.com/docs/
- React Documentation: https://reactjs.org/docs/
- Web3.js Documentation: https://web3js.readthedocs.io/
- MetaMask Documentation: https://docs.metamask.io/

**Community Support:**
- Ethereum Stack Exchange: https://ethereum.stackexchange.com/
- React Community: https://reactjs.org/community/support.html
- Truffle Community: https://github.com/trufflesuite/truffle

This completes the comprehensive execution guide for the Drug Supply Chain Management System. The system is now ready for use with proper blockchain integration and a user-friendly React frontend.

