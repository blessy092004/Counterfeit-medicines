const DrugSupplyChain = artifacts.require("DrugSupplyChain");

contract("DrugSupplyChain", (accounts) => {
  let drugSupplyChain;
  const owner = accounts[0];
  const manufacturer = accounts[1];
  const distributor = accounts[2];
  const pharmacist = accounts[3];

  beforeEach(async () => {
    drugSupplyChain = await DrugSupplyChain.new({ from: owner });
  });

  describe("Participant Registration", () => {
    it("should register a manufacturer", async () => {
      await drugSupplyChain.registerParticipant(
        manufacturer,
        "ABC Pharmaceuticals",
        "New York",
        0, // Role.Manufacturer
        { from: owner }
      );

      const participant = await drugSupplyChain.getParticipant(manufacturer);
      assert.equal(participant.name, "ABC Pharmaceuticals");
      assert.equal(participant.role, 0);
      assert.equal(participant.isActive, true);
    });

    it("should register a distributor", async () => {
      await drugSupplyChain.registerParticipant(
        distributor,
        "XYZ Distribution",
        "California",
        1, // Role.Distributor
        { from: owner }
      );

      const participant = await drugSupplyChain.getParticipant(distributor);
      assert.equal(participant.name, "XYZ Distribution");
      assert.equal(participant.role, 1);
    });

    it("should register a pharmacist", async () => {
      await drugSupplyChain.registerParticipant(
        pharmacist,
        "City Pharmacy",
        "Texas",
        2, // Role.Pharmacist
        { from: owner }
      );

      const participant = await drugSupplyChain.getParticipant(pharmacist);
      assert.equal(participant.name, "City Pharmacy");
      assert.equal(participant.role, 2);
    });
  });

  describe("Drug Batch Creation", () => {
    beforeEach(async () => {
      await drugSupplyChain.registerParticipant(
        manufacturer,
        "ABC Pharmaceuticals",
        "New York",
        0,
        { from: owner }
      );
    });

    it("should create a new drug batch", async () => {
      const drugName = "Aspirin";
      const manufacturerName = "ABC Pharmaceuticals";
      const manufacturingDate = Math.floor(Date.now() / 1000);
      const expiryDate = manufacturingDate + (365 * 24 * 60 * 60); // 1 year later
      const quantity = 1000;
      const location = "New York Factory";

      const result = await drugSupplyChain.createDrugBatch(
        drugName,
        manufacturerName,
        manufacturingDate,
        expiryDate,
        quantity,
        location,
        { from: manufacturer }
      );

      const batchId = result.logs[0].args.batchId;
      const batch = await drugSupplyChain.getDrugBatch(batchId);

      assert.equal(batch.drugName, drugName);
      assert.equal(batch.manufacturer, manufacturerName);
      assert.equal(batch.quantity, quantity);
      assert.equal(batch.status, 0); // DrugStatus.Manufactured
      assert.equal(batch.currentOwner, manufacturer);
    });

    it("should not allow non-manufacturers to create drug batches", async () => {
      try {
        await drugSupplyChain.createDrugBatch(
          "Aspirin",
          "ABC Pharmaceuticals",
          Math.floor(Date.now() / 1000),
          Math.floor(Date.now() / 1000) + (365 * 24 * 60 * 60),
          1000,
          "New York Factory",
          { from: distributor }
        );
        assert.fail("Should have thrown an error");
      } catch (error) {
        assert(error.message.includes("Only manufacturer can perform this action"));
      }
    });
  });

  describe("Drug Batch Transfer", () => {
    let batchId;

    beforeEach(async () => {
      await drugSupplyChain.registerParticipant(
        manufacturer,
        "ABC Pharmaceuticals",
        "New York",
        0,
        { from: owner }
      );

      await drugSupplyChain.registerParticipant(
        distributor,
        "XYZ Distribution",
        "California",
        1,
        { from: owner }
      );

      const result = await drugSupplyChain.createDrugBatch(
        "Aspirin",
        "ABC Pharmaceuticals",
        Math.floor(Date.now() / 1000),
        Math.floor(Date.now() / 1000) + (365 * 24 * 60 * 60),
        1000,
        "New York Factory",
        { from: manufacturer }
      );

      batchId = result.logs[0].args.batchId;
    });

    it("should transfer drug batch to distributor", async () => {
      await drugSupplyChain.transferDrugBatch(
        batchId,
        distributor,
        "California Warehouse",
        { from: manufacturer }
      );

      const batch = await drugSupplyChain.getDrugBatch(batchId);
      assert.equal(batch.currentOwner, distributor);
      assert.equal(batch.status, 1); // DrugStatus.InTransit
    });

    it("should maintain transfer history", async () => {
      await drugSupplyChain.transferDrugBatch(
        batchId,
        distributor,
        "California Warehouse",
        { from: manufacturer }
      );

      const history = await drugSupplyChain.getDrugBatchHistory(batchId);
      assert.equal(history.locationHistory.length, 2);
      assert.equal(history.ownerHistory.length, 2);
      assert.equal(history.ownerHistory[1], distributor);
    });
  });

  describe("Drug Status Updates", () => {
    let batchId;

    beforeEach(async () => {
      await drugSupplyChain.registerParticipant(
        manufacturer,
        "ABC Pharmaceuticals",
        "New York",
        0,
        { from: owner }
      );

      const result = await drugSupplyChain.createDrugBatch(
        "Aspirin",
        "ABC Pharmaceuticals",
        Math.floor(Date.now() / 1000),
        Math.floor(Date.now() / 1000) + (365 * 24 * 60 * 60),
        1000,
        "New York Factory",
        { from: manufacturer }
      );

      batchId = result.logs[0].args.batchId;
    });

    it("should update drug status", async () => {
      await drugSupplyChain.updateDrugStatus(batchId, 2, { from: manufacturer }); // DrugStatus.Received

      const batch = await drugSupplyChain.getDrugBatch(batchId);
      assert.equal(batch.status, 2);
    });

    it("should allow owner to recall drug batch", async () => {
      await drugSupplyChain.recallDrugBatch(batchId, { from: owner });

      const batch = await drugSupplyChain.getDrugBatch(batchId);
      assert.equal(batch.status, 4); // DrugStatus.Recalled
    });
  });

  describe("Drug Expiry Check", () => {
    it("should correctly identify expired drugs", async () => {
      await drugSupplyChain.registerParticipant(
        manufacturer,
        "ABC Pharmaceuticals",
        "New York",
        0,
        { from: owner }
      );

      const pastDate = Math.floor(Date.now() / 1000) - (30 * 24 * 60 * 60); // 30 days ago
      const result = await drugSupplyChain.createDrugBatch(
        "Expired Medicine",
        "ABC Pharmaceuticals",
        pastDate - (365 * 24 * 60 * 60),
        pastDate,
        100,
        "New York Factory",
        { from: manufacturer }
      );

      const batchId = result.logs[0].args.batchId;
      const isExpired = await drugSupplyChain.isDrugExpired(batchId);
      assert.equal(isExpired, true);
    });
  });
});

