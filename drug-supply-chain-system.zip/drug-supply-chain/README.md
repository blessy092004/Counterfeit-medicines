# Blockchain-based Drug Supply Chain Management System

This project provides a secure and transparent solution for tracking drugs through the supply chain, from manufacturer to consumer, using blockchain technology and a React-based frontend. It aims to combat the issue of counterfeit drugs by providing an immutable and auditable record of each drug's journey.

## 🚀 Quick Start

1. **Extract the project files** to your desired location
2. **Install dependencies**: `npm install` (root) and `cd client && pnpm install`
3. **Start blockchain**: `npx ganache-cli --deterministic --accounts 10 --host 0.0.0.0 --port 8545`
4. **Deploy contracts**: `npx truffle migrate --network development`
5. **Copy artifacts**: `cp -r build client/src/`
6. **Start frontend**: `cd client && pnpm run dev --host`
7. **Access application**: Open http://localhost:5173

## 📋 Prerequisites

- Node.js 18.0.0 or higher
- npm or pnpm package manager
- Modern web browser
- MetaMask extension (optional but recommended)

## 🏗️ Architecture

### Components
- **Blockchain Network**: Ethereum-based immutable ledger
- **Smart Contracts**: Solidity contracts governing drug tracking logic
- **React Frontend**: User interface for supply chain participants

### Technology Stack
- **Blockchain**: Ethereum, Solidity, Truffle, Ganache
- **Frontend**: React.js, Vite, Tailwind CSS, Web3.js
- **UI Components**: shadcn/ui, Lucide icons
- **Testing**: Mocha, Chai

## 🔧 Features

- **Drug Registration**: Manufacturers can register new drug batches
- **Ownership Transfer**: Secure transfer between supply chain participants
- **Status Updates**: Real-time tracking of drug status and location
- **Complete Traceability**: Full history from manufacturing to dispensing
- **Counterfeit Detection**: Blockchain verification prevents fake drugs
- **Role-Based Access**: Different permissions for manufacturers, distributors, pharmacists
- **Expiry Monitoring**: Automatic detection of expired medications
- **Recall Management**: System-wide recall capabilities

## 👥 User Roles

- **Manufacturer**: Create drug batches, transfer to distributors
- **Distributor**: Receive from manufacturers, transfer to pharmacists
- **Pharmacist**: Receive from distributors, dispense to consumers
- **Consumer**: Verify drug authenticity and history

## 📚 Documentation

- **[EXECUTION_GUIDE.md](EXECUTION_GUIDE.md)**: Comprehensive setup and usage instructions
- **[FILE_STRUCTURE.md](FILE_STRUCTURE.md)**: Detailed project organization explanation
- **[HOW_IT_WORKS.md](HOW_IT_WORKS.md)**: Application functionality and workflow details

## 🧪 Testing

Run the smart contract test suite:
```bash
npx truffle test
```

## 🔒 Security Features

- Role-based access control
- Cryptographic transaction signing
- Immutable blockchain records
- Ownership validation
- Participant authorization

## 🌐 Browser Support

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## 📄 License

This project is provided as-is for educational and demonstration purposes.

## 🤝 Support

For detailed setup instructions, troubleshooting, and usage guidance, please refer to the comprehensive documentation files included in this package.

